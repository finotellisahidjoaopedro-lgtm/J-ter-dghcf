# VEX — Real Estate Landing Page

A single-page, cinematic real estate landing page built with React, TypeScript, Vite and Tailwind CSS.

## Setup

```bash
npm install
npm run dev
```

Then open the printed local URL in your browser.

## The hero video

The hero section expects a video at `public/videos/hero.mp4` (referenced in
`src/components/Hero.tsx`). That file isn't included in this project — drop your
generated hero video into `public/videos/hero.mp4` and it will play full-screen,
raw, with no overlay, exactly as specified. Until then, the `poster` image on the
`<video>` tag is shown as a placeholder.

## Structure

- `src/components/Hero.tsx` — full-viewport video hero, animated heading, CTAs
- `src/components/Navbar.tsx` — liquid-glass nav, fixed, with mobile menu
- `src/components/FeaturedProperty.tsx` — editorial section for the flagship listing
- `src/components/ExploreProperties.tsx` — 3-card property grid
- `src/components/Locations.tsx` — 3 large location blocks
- `src/components/About.tsx` — agency statement
- `src/components/FinalCTA.tsx` — closing call to action
- `src/components/Footer.tsx` — minimal footer
- `src/components/AnimatedHeading.tsx` — per-character reveal used by the hero headline
- `src/components/FadeIn.tsx` — reusable fade-in wrapper used throughout
- `src/data/properties.ts` — property and location content

## Notes

- Palette is strictly black/white/gray per the brief — no purple, indigo, blue or gradients.
- The `.liquid-glass` utility (in `src/index.css`) matches the spec exactly: `rgba(0,0,0,0.4)` background, `blur(4px)`, and a soft gradient border via a masked `::before`.
- Placeholder property and location photography comes from Unsplash — swap the URLs in `src/data/properties.ts` for real listing photos when available.
