export interface Property {
  id: string;
  name: string;
  location: string;
  price: string;
  beds: number;
  baths: number;
  area: string;
  image: string;
}

export const featuredProperty: Property = {
  id: 'casa-horizonte',
  name: 'Casa Horizonte',
  location: 'S\u00e3o Paulo, Brazil',
  price: 'R$ 8.900.000',
  beds: 4,
  baths: 5,
  area: '420 m\u00b2',
  image:
    'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?q=80&w=1800&auto=format&fit=crop',
};

export const properties: Property[] = [
  {
    id: 'casa-aurora',
    name: 'Casa Aurora',
    location: 'Rio de Janeiro, Brazil',
    price: 'R$ 6.500.000',
    beds: 3,
    baths: 4,
    area: '310 m\u00b2',
    image:
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=1400&auto=format&fit=crop',
  },
  {
    id: 'casa-mar',
    name: 'Casa Mar',
    location: 'Trancoso, Brazil',
    price: 'R$ 5.200.000',
    beds: 3,
    baths: 3,
    area: '260 m\u00b2',
    image:
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?q=80&w=1400&auto=format&fit=crop',
  },
  {
    id: 'casa-vale',
    name: 'Casa Vale',
    location: 'S\u00e3o Paulo, Brazil',
    price: 'R$ 7.100.000',
    beds: 4,
    baths: 4,
    area: '350 m\u00b2',
    image:
      'https://images.unsplash.com/photo-1613977257363-707ba9348227?q=80&w=1400&auto=format&fit=crop',
  },
];

export const locations = [
  {
    id: 'sao-paulo',
    name: 'S\u00e3o Paulo',
    description: 'Where the skyline never quite settles.',
    image:
      'https://images.unsplash.com/photo-1543059080-f9b1272213d5?q=80&w=1400&auto=format&fit=crop',
  },
  {
    id: 'rio-de-janeiro',
    name: 'Rio de Janeiro',
    description: 'Mountains, coastline, and everything between.',
    image:
      'https://images.unsplash.com/photo-1483729558449-99ef09a8c325?q=80&w=1400&auto=format&fit=crop',
  },
  {
    id: 'trancoso',
    name: 'Trancoso',
    description: 'Slower mornings, further south.',
    image:
      'https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?q=80&w=1400&auto=format&fit=crop',
  },
];
