import Navbar from './components/Navbar';
import Hero from './components/Hero';
import FeaturedProperty from './components/FeaturedProperty';
import ExploreProperties from './components/ExploreProperties';
import Locations from './components/Locations';
import About from './components/About';
import FinalCTA from './components/FinalCTA';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-black font-sans text-white">
      <Navbar />
      <main>
        <Hero />
        <FeaturedProperty />
        <ExploreProperties />
        <Locations />
        <About />
        <FinalCTA />
      </main>
      <Footer />
    </div>
  );
}
