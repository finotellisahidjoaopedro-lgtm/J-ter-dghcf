import { Instagram, Linkedin } from 'lucide-react';

const navLinks = [
  { label: 'Properties', href: '#properties' },
  { label: 'Locations', href: '#locations' },
  { label: 'About', href: '#about' },
  { label: 'Contact', href: '#contact' },
];

export default function Footer() {
  return (
    <footer className="border-t border-white/[0.08] bg-black px-6 py-10 sm:px-10 lg:px-16">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-6 sm:flex-row">
        <span className="text-sm font-semibold tracking-tight text-white">VEX</span>

        <nav>
          <ul className="flex flex-wrap items-center justify-center gap-6">
            {navLinks.map((link) => (
              <li key={link.label}>
                <a
                  href={link.href}
                  className="text-sm text-gray-400 transition-colors hover:text-white"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="flex items-center gap-4">
          <a href="#" aria-label="Instagram" className="text-gray-400 transition-colors hover:text-white">
            <Instagram size={18} />
          </a>
          <a href="#" aria-label="LinkedIn" className="text-gray-400 transition-colors hover:text-white">
            <Linkedin size={18} />
          </a>
        </div>
      </div>

      <p className="mt-8 text-center text-xs text-gray-500">
        &copy; {new Date().getFullYear()} VEX. All rights reserved.
      </p>
    </footer>
  );
}
