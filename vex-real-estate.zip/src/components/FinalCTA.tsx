import FadeIn from './FadeIn';

export default function FinalCTA() {
  return (
    <section id="contact" className="border-t border-white/[0.08] bg-black px-6 py-24 sm:px-10 lg:px-16">
      <FadeIn className="mx-auto max-w-2xl text-center">
        <h2 className="text-3xl font-normal tracking-tight text-white sm:text-4xl">
          Ready to find your next address?
        </h2>
        <p className="mt-4 text-base text-gray-300">
          Tell us what you're looking for and our team will help you find the right property.
        </p>
        <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
          <a
            href="#top"
            className="rounded-lg bg-white px-8 py-3 text-sm font-medium text-black"
          >
            Start a Conversation
          </a>
          <a
            href="#properties"
            className="liquid-glass rounded-lg border border-white/20 px-8 py-3 text-sm font-medium text-white"
          >
            Explore Properties
          </a>
        </div>
      </FadeIn>
    </section>
  );
}
