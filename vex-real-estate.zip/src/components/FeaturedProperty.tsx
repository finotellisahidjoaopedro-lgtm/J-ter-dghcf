import FadeIn from './FadeIn';
import { featuredProperty } from '../data/properties';

export default function FeaturedProperty() {
  return (
    <section className="border-t border-white/[0.08] bg-black">
      <div className="mx-auto flex max-w-7xl flex-col lg:flex-row">
        <FadeIn className="lg:w-3/5">
          <div className="aspect-[4/3] w-full overflow-hidden lg:aspect-auto lg:h-[640px]">
            <img
              src={featuredProperty.image}
              alt={featuredProperty.name}
              className="h-full w-full object-cover"
            />
          </div>
        </FadeIn>

        <FadeIn delay={150} className="flex items-center lg:w-2/5">
          <div className="px-6 py-12 sm:px-10 lg:px-14">
            <p className="text-xs font-medium tracking-[0.14em] text-gray-400">
              Featured Property
            </p>

            <h2 className="mt-4 text-3xl font-normal tracking-tight text-white sm:text-4xl">
              {featuredProperty.name}
            </h2>
            <p className="mt-2 text-sm text-gray-300">{featuredProperty.location}</p>

            <dl className="mt-8 grid grid-cols-3 gap-4 border-y border-white/10 py-6">
              <div>
                <dt className="text-xs text-gray-400">Bed</dt>
                <dd className="mt-1 text-lg text-white">{featuredProperty.beds}</dd>
              </div>
              <div>
                <dt className="text-xs text-gray-400">Bath</dt>
                <dd className="mt-1 text-lg text-white">{featuredProperty.baths}</dd>
              </div>
              <div>
                <dt className="text-xs text-gray-400">Area</dt>
                <dd className="mt-1 text-lg text-white">{featuredProperty.area}</dd>
              </div>
            </dl>

            <p className="mt-6 text-xl text-white">{featuredProperty.price}</p>

            <a
              href="#contact"
              className="mt-8 inline-block text-sm font-medium text-white underline-offset-4 hover:underline"
            >
              View Property &rarr;
            </a>
          </div>
        </FadeIn>
      </div>
    </section>
  );
}
