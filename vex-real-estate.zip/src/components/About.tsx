import FadeIn from './FadeIn';

export default function About() {
  return (
    <section id="about" className="border-t border-white/[0.08] bg-black px-6 py-20 sm:px-10 lg:px-16">
      <div className="mx-auto grid max-w-7xl grid-cols-1 items-center gap-12 lg:grid-cols-2">
        <FadeIn>
          <p className="text-xs font-medium tracking-[0.14em] text-gray-400">About Us</p>
          <h2 className="mt-4 text-3xl font-normal tracking-tight text-white sm:text-4xl">
            Real estate, with a different perspective.
          </h2>
          <p className="mt-6 max-w-md text-base leading-relaxed text-gray-300">
            We work with a small number of properties at a time, so every listing gets the
            attention a home this considered deserves. From first walkthrough to closing,
            our team stays close to the details that actually matter.
          </p>
          <a
            href="#contact"
            className="mt-8 inline-block text-sm font-medium text-white underline-offset-4 hover:underline"
          >
            Learn More &rarr;
          </a>
        </FadeIn>

        <FadeIn delay={150}>
          <div className="aspect-[4/5] w-full overflow-hidden rounded-lg">
            <img
              src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?q=80&w=1400&auto=format&fit=crop"
              alt="Architectural detail of a modern residence"
              className="h-full w-full object-cover"
            />
          </div>
        </FadeIn>
      </div>
    </section>
  );
}
