import FadeIn from './FadeIn';
import { locations } from '../data/properties';

export default function Locations() {
  return (
    <section id="locations" className="border-t border-white/[0.08] bg-black py-20">
      <div className="mx-auto max-w-7xl px-6 sm:px-10 lg:px-16">
        <FadeIn>
          <h2 className="text-3xl font-normal tracking-tight text-white sm:text-4xl">
            Exceptional Locations
          </h2>
        </FadeIn>
      </div>

      <div className="mt-10 grid grid-cols-1 gap-1 sm:grid-cols-3">
        {locations.map((location, index) => (
          <FadeIn key={location.id} delay={index * 120}>
            <a href="#contact" className="group relative block h-[420px] w-full overflow-hidden">
              <img
                src={location.image}
                alt={location.name}
                className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
              <div className="absolute bottom-0 left-0 p-6">
                <h3 className="text-xl text-white">{location.name}</h3>
                <p className="mt-1 text-sm text-gray-300">{location.description}</p>
              </div>
            </a>
          </FadeIn>
        ))}
      </div>
    </section>
  );
}
