import FadeIn from './FadeIn';
import { properties } from '../data/properties';

export default function ExploreProperties() {
  return (
    <section id="properties" className="border-t border-white/[0.08] bg-black px-6 py-20 sm:px-10 lg:px-16">
      <div className="mx-auto max-w-7xl">
        <FadeIn className="max-w-xl">
          <h2 className="text-3xl font-normal tracking-tight text-white sm:text-4xl">
            Explore Properties
          </h2>
          <p className="mt-3 text-base text-gray-300">
            A curated selection of residences chosen for architecture, location and lifestyle.
          </p>
        </FadeIn>

        <div className="mt-12 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {properties.map((property, index) => (
            <FadeIn key={property.id} delay={index * 120}>
              <a href="#contact" className="group block">
                <div className="aspect-[4/5] w-full overflow-hidden rounded-lg">
                  <img
                    src={property.image}
                    alt={property.name}
                    className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                  />
                </div>
                <div className="mt-4 flex items-start justify-between">
                  <div>
                    <h3 className="text-base text-white">{property.name}</h3>
                    <p className="mt-1 text-sm text-gray-400">{property.location}</p>
                  </div>
                  <p className="text-sm text-gray-300">{property.price}</p>
                </div>
                <p className="mt-2 text-xs text-gray-500">
                  {property.beds} BED &middot; {property.baths} BATH &middot; {property.area}
                </p>
              </a>
            </FadeIn>
          ))}
        </div>

        <FadeIn delay={400} className="mt-12">
          <a
            href="#contact"
            className="text-sm font-medium text-white underline-offset-4 hover:underline"
          >
            View All Properties &rarr;
          </a>
        </FadeIn>
      </div>
    </section>
  );
}
