import AnimatedHeading from './AnimatedHeading';
import FadeIn from './FadeIn';

export default function Hero() {
  return (
    <section id="top" className="relative h-screen w-full overflow-hidden bg-black">
      {/* Full-screen background video, shown raw with no overlay.
          Replace src below with the generated hero video. */}
      <video
        className="absolute inset-0 h-full w-full object-cover"
        autoPlay
        muted
        loop
        playsInline
        poster="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?q=80&w=2000&auto=format&fit=crop"
      >
        <source src="/videos/hero.mp4" type="video/mp4" />
      </video>

      <div className="relative z-10 flex h-full w-full flex-col justify-end px-6 pb-16 sm:px-10 sm:pb-20 lg:px-16">
        <div className="flex flex-col items-end justify-between gap-10 lg:flex-row lg:items-end">
          <div className="max-w-2xl">
            <AnimatedHeading
              as="h1"
              lines={['Find a place worth', 'calling home.']}
              className="text-5xl font-normal tracking-tightest2 text-white sm:text-6xl xl:text-7xl"
            />

            <FadeIn delay={900} duration={600}>
              <p className="mt-6 max-w-md text-base text-gray-300 sm:text-lg">
                Exceptional properties, carefully selected for the way you want to live.
              </p>
            </FadeIn>

            <FadeIn delay={1100} duration={600}>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <a
                  href="#properties"
                  className="rounded-lg bg-white px-8 py-3 text-center text-sm font-medium text-black"
                >
                  Explore Properties
                </a>
                <a
                  href="#contact"
                  className="liquid-glass rounded-lg border border-white/20 px-8 py-3 text-center text-sm font-medium text-white"
                >
                  Talk to an Advisor
                </a>
              </div>
            </FadeIn>
          </div>

          <FadeIn delay={1300} duration={600} className="hidden shrink-0 lg:block">
            <div className="liquid-glass w-64 rounded-xl px-6 py-5">
              <p className="text-sm leading-relaxed text-gray-200">
                Curated properties. Exceptional locations.
              </p>
            </div>
          </FadeIn>
        </div>
      </div>
    </section>
  );
}
