import { useEffect, useState, type ReactNode } from 'react';

interface FadeInProps {
  children: ReactNode;
  delay?: number;
  duration?: number;
  className?: string;
}

/**
 * Reusable fade-in wrapper. Opacity 0 -> 1 after a configurable delay,
 * driven by a timeout + React state and a Tailwind opacity transition.
 */
export default function FadeIn({
  children,
  delay = 0,
  duration = 700,
  className = '',
}: FadeInProps) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setVisible(true), delay);
    return () => clearTimeout(timer);
  }, [delay]);

  return (
    <div
      className={`${className} transition-opacity ease-out`}
      style={{
        opacity: visible ? 1 : 0,
        transitionDuration: `${duration}ms`,
      }}
    >
      {children}
    </div>
  );
}
