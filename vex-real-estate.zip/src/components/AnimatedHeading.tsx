import { useEffect, useState } from 'react';

interface AnimatedHeadingProps {
  lines: string[];
  as?: 'h1' | 'h2' | 'h3';
  className?: string;
  initialDelay?: number;
  charDelay?: number;
}

/**
 * Splits text by line, then each line into characters. Each character
 * animates from opacity:0 / translateX(-18px) to opacity:1 / translateX(0),
 * staggered by charDelay across the whole heading, starting after initialDelay.
 */
export default function AnimatedHeading({
  lines,
  as = 'h1',
  className = '',
  initialDelay = 200,
  charDelay = 30,
}: AnimatedHeadingProps) {
  const [visible, setVisible] = useState(false);
  const Tag = as;

  useEffect(() => {
    const timer = setTimeout(() => setVisible(true), initialDelay);
    return () => clearTimeout(timer);
  }, [initialDelay]);

  let globalIndex = 0;

  return (
    <Tag className={className}>
      {lines.map((line, lineIndex) => (
        <span className="block" key={lineIndex}>
          {line.split('').map((char, charIndex) => {
            const delayMs = globalIndex * charDelay;
            globalIndex += 1;
            return (
              <span
                key={`${lineIndex}-${charIndex}`}
                className={`char-in${visible ? ' is-visible' : ''}`}
                style={{ transitionDelay: `${delayMs}ms` }}
              >
                {char === ' ' ? '\u00A0' : char}
              </span>
            );
          })}
        </span>
      ))}
    </Tag>
  );
}
