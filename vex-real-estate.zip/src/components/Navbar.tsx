import { useState } from 'react';
import { Menu, X } from 'lucide-react';

const links = ['Story', 'Properties', 'Locations', 'About'];

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="fixed top-4 left-1/2 z-50 w-[calc(100%-2rem)] max-w-6xl -translate-x-1/2 sm:top-6">
      <nav className="liquid-glass flex items-center justify-between rounded-xl px-4 py-2">
        <a href="#top" className="text-sm font-semibold tracking-tight text-white">
          VEX
        </a>

        <ul className="hidden items-center gap-8 md:flex">
          {links.map((link) => (
            <li key={link}>
              <a
                href={`#${link.toLowerCase()}`}
                className="text-sm font-normal text-gray-300 transition-colors hover:text-white"
              >
                {link}
              </a>
            </li>
          ))}
        </ul>

        <a
          href="#contact"
          className="hidden rounded-lg bg-white px-4 py-2 text-sm font-medium text-black md:inline-block"
        >
          Start a Chat
        </a>

        <button
          type="button"
          aria-label={open ? 'Close menu' : 'Open menu'}
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
          className="rounded-lg p-2 text-white md:hidden"
        >
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </nav>

      {open && (
        <div className="liquid-glass mt-2 rounded-xl px-4 py-4 md:hidden">
          <ul className="flex flex-col gap-4">
            {links.map((link) => (
              <li key={link}>
                <a
                  href={`#${link.toLowerCase()}`}
                  onClick={() => setOpen(false)}
                  className="text-sm text-gray-300 transition-colors hover:text-white"
                >
                  {link}
                </a>
              </li>
            ))}
            <li>
              <a
                href="#contact"
                onClick={() => setOpen(false)}
                className="mt-1 block w-full rounded-lg bg-white px-4 py-2 text-center text-sm font-medium text-black"
              >
                Start a Chat
              </a>
            </li>
          </ul>
        </div>
      )}
    </header>
  );
}
