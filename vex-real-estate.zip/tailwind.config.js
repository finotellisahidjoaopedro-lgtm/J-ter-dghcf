/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
      },
      colors: {
        ink: '#000000',
        paper: '#FFFFFF',
        mute: '#D1D5DB',
      },
      letterSpacing: {
        tightest2: '-0.04em',
      },
    },
  },
  plugins: [],
};
